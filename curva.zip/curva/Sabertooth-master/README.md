# Sabertoooth

This is a repo for studying purposes only.

## Todo:

* Change the drawable method Draw to a virtual method.
