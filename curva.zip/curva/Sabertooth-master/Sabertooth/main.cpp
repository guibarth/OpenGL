#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <GL\glew.h>
#include "Shader.h"
#include <glm\glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GLFW\glfw3.h>
#include <vector>
#include <glm\vec2.hpp>
#include <fstream>
#include <sstream>

#define PI  3.14159265359
#define half_PI PI/2.0

using namespace std;

const GLint WIDTH = 1200, HEIGHT = 900;

//Projeto Screensaver
//Membros: Guilherme Barth, Robson Chiarello, Willian Werlang

//vector with points for the curve
vector<glm::vec3*>* curvePoints = new vector<glm::vec3*>();
vector<glm::vec3*>* curvePoints_external = new vector<glm::vec3*>();
vector<glm::vec3*>* ext_curvePoints = new vector<glm::vec3*>();
vector<GLfloat> *ext_curvePoints2 = new vector<GLfloat>();
vector<GLfloat> *finalVector = new vector<GLfloat>();;
bool draw = false;
GLuint vao, vbo, vao1, vbo1;


//callback for mouse
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
void convertCoordinates(double &x, double &y);
vector<glm::vec3*>* generateBSpline(vector<glm::vec3*>* points);
std::vector<GLfloat>* convertPoints(std::vector<glm::vec3*>* points);
int getZone(float x, float y);
vector<glm::vec3*>* generateBSplineBasedOnInternal(vector<glm::vec3*>* points);

int main() {

#pragma region OpenGL Init
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
	glfwWindowHint(GLFW_SAMPLES, 4);
#pragma endregion

#pragma region Basic Setup
	GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "Screensaver", nullptr, nullptr);

	int screenWidth, screenHeight;
	glfwGetFramebufferSize(window, &screenWidth, &screenHeight);

	if (window == nullptr) {
		std::cout << "Failed to create GLFW Window" << std::endl;
		glfwTerminate();

		return EXIT_FAILURE;
	}

	glfwMakeContextCurrent(window);
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK) {
		std::cout << "Failed no init GLEW." << std::endl;
		return EXIT_FAILURE;
	}

	glViewport(0, 0, screenWidth, screenHeight);
#pragma endregion

	Shader coreShader("Shaders/Core/core.vert", "Shaders/Core/core.frag");

	GLfloat vertices[] = {
		// Positions		    // Colors
		+0.3f, -0.3f, +0.0f,	1.0f, 0.0f, 0.0f,
		-0.3f, -0.3f, +0.0f,	0.0f, 1.0f, 0.0f,
		+0.0f, +0.3f, +0.0f,	0.0f, 0.0f, 1.0f
	};

	float matrix[] = {
		1.0f, 0.0f, 0.0f, 0.0f, // 1� coluna
		0.0f, 1.0f, 0.0f, 0.0f, // 2� coluna
		0.0f, 0.0f, 1.0f, 0.0f, // 3� coluna
		0.25f, 0.25f, 0.0f, 1.0f // 4� coluna
	};

	GLfloat line_points[] = {0.0f, 0.0f, 0.0f,  1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f, 1.0f, 0.5f, 0.5f, 0.5f,  1.0f, 1.0f, 1.0f, -0.0f, -0.5f, -0.5f,  1.0f, 1.0f, 1.0f };
	GLfloat color_points[] = { 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f };

	const char* fragment_shader =
		"#version 410\n"
		"in vec3 color;"
		"out vec4 frag_color;"
		"void main () {"
		" frag_color = vec4 (color, 1.0);"
		"}";

	const char* vertex_shader =
		"#version 410\n"
		"layout(location=0) in vec3 vp;"
		"layout(location=1) in vec3 vc;"
		"uniform mat4 matrix;"
		"out vec3 color;"
		"void main () {"
		" color = vc;"
		" gl_Position = vec4 (vp, 1.0);"
		"}";

// � mais adiante 

	// identifica vs e o associa com vertex_shader
	GLuint vs = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vs, 1, &vertex_shader, NULL);
	glCompileShader(vs);
	// identifica fs e o associa com fragment_shader
	GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fs, 1, &fragment_shader, NULL);
	glCompileShader(fs);
	// identifica do programa, adiciona partes e faz "linkagem"
	GLuint shader_programme = glCreateProgram();
	glAttachShader(shader_programme, fs);
	glAttachShader(shader_programme, vs);
	glLinkProgram(shader_programme);

	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);

	glGenVertexArrays(1, &vao1);
	glGenBuffers(1, &vbo1);

	int matrixLocation = glGetUniformLocation(shader_programme, "matrix");
	glUseProgram(shader_programme);
	glUniformMatrix4fv(matrixLocation, 1, GL_FALSE, matrix);

	float speed = 0.8f;
	float lastPositionX = 0.0f;
	float lastPositionY = 0.0f;
	glm::vec3 vecDir = glm::vec3(1.0f, 0.8f, 0.0f);

	glfwMakeContextCurrent(window);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	

	while (!glfwWindowShouldClose(window)) {
		glClear(1);
		
		glfwPollEvents();

		if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
			glfwSetWindowShouldClose(window, GLFW_TRUE);
		}


		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		// Define vao como verte array atual
		glBindVertexArray(vao);
		// desenha pontos a partir do p0 e 3 no total do VAO atual com o shader
		// atualmente em uso


		if (draw == true) {
			glDrawArrays(GL_LINES, 0, finalVector->size());
			//glDrawArrays(GL_LINE_STRIP, 0, finalVector->size());
			glBindVertexArray(vao1);
			glDrawArrays(GL_LINES, 0, ext_curvePoints2->size());
		}		

		glfwSwapBuffers(window);
	}

	

	glfwTerminate();

	return EXIT_SUCCESS;
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		//glfwMakeContextCurrent(window);
		//glfwSetCursorPosCallback(window, mouse_pos_callback);	
		double xpos, ypos;
		glfwGetCursorPos(window, &xpos, &ypos);

		// glfwGetCursorPos gets the mouse position based on the resolution
		// then we convert it to -1 ... 1 coordinates
		convertCoordinates(xpos, ypos);
		
		glm::vec3* point = new glm::vec3(xpos, ypos, 0.0);
		curvePoints->push_back(point);
		cout << "point recorded" << endl;
		cout << xpos << endl;
		cout << ypos << endl;		

		//trying to generate second curve
		int zone = getZone(xpos, ypos);
		if (zone == 1) {
			xpos += 0.5;
			ypos += 0.5;
		}
		else if (zone == 2) {
			xpos -= 0.5;
			ypos += 0.5;
		}
		else if (zone == 3) {
			xpos -= 0.5;
			ypos -= 0.5;
		}
		else if (zone == 4) {
			xpos += 0.5;
			ypos -= 0.5;
		}
		curvePoints_external->push_back(new glm::vec3(xpos, ypos, 0.0));

	}	
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS) {
		draw = true;
		
		curvePoints = generateBSpline(curvePoints);
		//trying to get external curve based on the calculated curve
		ext_curvePoints = generateBSplineBasedOnInternal(curvePoints);
		finalVector = convertPoints(curvePoints);

		
		ext_curvePoints2 = convertPoints(ext_curvePoints);
		//curvePoints_external = generateBSpline(curvePoints_external);
		//ext_curvePoints2 = convertPoints(curvePoints_external);
		
		glBindVertexArray(vao);

		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*finalVector->size(), &finalVector->at(0), GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid *)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid *)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glBindVertexArray(0);


		//for the ext curve
		glBindVertexArray(vao1);

		glBindBuffer(GL_ARRAY_BUFFER, vbo1);
		glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*ext_curvePoints2->size(), &ext_curvePoints2->at(0), GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid *)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid *)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glBindVertexArray(0);

	}
}

//vector<glm::vec3*>* 
vector<glm::vec3*>* generateBSpline(vector<glm::vec3*>* points) {
	vector<glm::vec3*>* calculatedCurve = new vector<glm::vec3*>();

	vector<glm::vec3*>* temp = new vector<glm::vec3*>();

	vector<glm::vec3*>* temp2 = new vector<glm::vec3*>();

	for (int i = 0; i < points->size(); i++) {
		temp->push_back(new glm::vec3(points->at(i)->x, points->at(i)->y, 0));
	}

	//close the curve
	temp->push_back(points->at(0));
	temp->push_back(points->at(1));
	temp->push_back(points->at(2));

	//iterate through the collected points
	for (int i = 0; i < (temp->size() - 3); i++) {

		for (int j = 0; j<1000; ++j){

			float t = static_cast<float>(j) / 999.0;
		
			GLfloat x = (((-1 * pow(t, 3) + 3 * pow(t, 2) - 3 * t + 1)*temp->at(i)->x +
				(3 * pow(t, 3) - 6 * pow(t, 2) + 0 * t + 4)*temp->at(i+1)->x +
				(-3 * pow(t, 3) + 3 * pow(t, 2) + 3 * t + 1)*temp->at(i+2)->x +
				(1 * pow(t, 3) + 0 * pow(t, 2) + 0 * t + 0)*temp->at(i+3)->x) / 6);

			GLfloat y = (((-1 * pow(t, 3) + 3 * pow(t, 2) - 3 * t + 1)*temp->at(i)->y +
				(3 * pow(t, 3) - 6 * pow(t, 2) + 0 * t + 4)*temp->at(i+1)->y +
				(-3 * pow(t, 3) + 3 * pow(t, 2) + 3 * t + 1)*temp->at(i+2)->y +
				(1 * pow(t, 3) + 0 * pow(t, 2) + 0 * t + 0)*temp->at(i+3)->y) / 6);
		
			
			calculatedCurve->push_back(new glm::vec3(x, y, 0.0));		
			calculatedCurve->push_back(new glm::vec3(1.0, 1.0, 1.0));
			cout << "point added" << endl;
			
			
		}	
	}

	cout << "points calculated" << endl;
	return calculatedCurve;
}

void convertCoordinates(double &x, double &y) {
	//convert resolution coordinates to graph coordinates
	if (x > (WIDTH / 2)) {
		x = x - (WIDTH / 2);
		x = x / (WIDTH / 2);
	}
	else if (x == (WIDTH / 2)) {
		x = 0;
	}
	else {
		x = -(((WIDTH / 2) - x) / (WIDTH / 2));
	}

	if (y > (HEIGHT / 2)) {
		y = y - (HEIGHT / 2);
		y = y / (HEIGHT / 2);
		y = y * (-1); //necessary since the resolution coordinates start on the top left corner
	}
	else if (y == (HEIGHT / 2)) {
		y = 0;
	}
	else {
		y = -(((HEIGHT / 2) - y) / (HEIGHT / 2));
		y = y * (-1);
	}
}

//convert from vec3 to GLfloat
std::vector<GLfloat>* convertPoints(std::vector<glm::vec3*>* points) {
	std:vector<GLfloat>* temp = new std::vector<GLfloat>();
	glm::vec3* first = points->at(0);
	
	for (int i = 0; i < points->size(); i++) {
		temp->push_back(points->at(i)->x);
		temp->push_back(points->at(i)->y);
		temp->push_back(points->at(i)->z);
	}

	return temp;
}

int getZone(float x, float y) {
	if (x > 0.0 && y > 0.0){
		return 1;
	}
	else if (x > 0.0 && y < 0.0) {
		return 4;
	}
	else if (x < 0.0 && y < 0.0) {
		return 3;
	}else{
		return 2;
	}
}


//try to generate external curve based on internal
vector<glm::vec3*>* generateBSplineBasedOnInternal(vector<glm::vec3*>* points) {
	vector<glm::vec3*>* calculatedCurve = new vector<glm::vec3*>();
	
	//points->at(0) = new glm::vec3(0, 0, 0);
	//points->at(2) = new glm::vec3(0.707f, 0.707f, 0.f);
	
	/*for (int j = 0; j < points->size() - 2; j += 2) {
		
		GLfloat ABx = points->at(j + 2)->x - points->at(j)->x;
		GLfloat ABy = points->at(j + 2)->y - points->at(j)->y;
		glm::vec3 AB = normalize(glm::vec3(ABx, ABy, 0.0f));
		glm::vec3 AD = glm::vec3(1.0f, 0.0f, 0.0f);

		GLfloat esc = glm::dot(AD, AB);
		float ang = glm::acos(esc) +
			half_PI;

		GLfloat offsetX = glm::cos(ang);
		GLfloat offsetY = glm::sin(ang);

		glm::vec3* pointGenerated = new glm::vec3(points->at(j)->x + offsetX, points->at(j)->y + offsetY, 0.0);

		calculatedCurve->push_back(pointGenerated);
		calculatedCurve->push_back(new glm::vec3(1.0, 1.0, 1.0));
	}*/

	for (int j = 0; j < points->size() - 2; j += 2) {

		GLfloat dx = points->at(j + 2)->x - points->at(j)->x;
		GLfloat dy = points->at(j + 2)->y - points->at(j)->y;
		glm::vec3 dVector = normalize(glm::vec3(dx, dy, 0.0f));

		GLfloat atan = glm::atan(dy/dx);
		float ang;
		/*
		if (getZone(points->at(j)->x, points->at(j)->y) == 1 || getZone(points->at(j)->x, points->at(j)->y) == 2){
			ang = atan + half_PI;
		}
		else {
			ang = atan - half_PI;
		}
		*/
		GLfloat offsetX = glm::cos(atan);
		GLfloat offsetY = glm::sin(atan);

		glm::vec3* pointGenerated = new glm::vec3(points->at(j)->x + offsetX, points->at(j)->y + offsetY, 0.0);

		calculatedCurve->push_back(pointGenerated);
		calculatedCurve->push_back(new glm::vec3(1.0, 1.0, 1.0));
	}
	
	return calculatedCurve;



}






//Bezier curve algorithm
/*
GLfloat x = (1 - 2*t + pow(t,2) - t + 2*(pow(t, 2)) - pow(t, 3))*temp->at(i)->x + //p0
(3 - 6*t + 3* pow(t, 2))*t*temp->at(i+1)->x + //p1
(3 - 3*t)*(pow(t, 2)) * temp->at(i+2)->x + //p2
pow(t, 3) * temp->at(i+3)->x; //p3

GLfloat y = (1 - 2 * t + pow(t, 2) - t + 2 * (pow(t, 2)) - pow(t, 3))*temp->at(i)->y + //p0
(3 - 6 * t + 3 * pow(t, 2))*t*temp->at(i + 1)->y + //p1
(3 - 3 * t)*(pow(t, 2)) * temp->at(i + 2)->y + //p2
pow(t, 3) * temp->at(i + 3)->y; //p3
*/