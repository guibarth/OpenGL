#include "Shader.h"



Shader::Shader()
{
}


Shader::~Shader()
{
}
